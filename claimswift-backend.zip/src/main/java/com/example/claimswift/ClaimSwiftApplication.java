package com.example.claimswift;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class ClaimSwiftApplication {
 public static void main(String[] args){SpringApplication.run(ClaimSwiftApplication.class,args);}
}