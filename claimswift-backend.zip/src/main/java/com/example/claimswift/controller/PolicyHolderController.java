package com.example.claimswift.controller;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/policyholder")
public class PolicyHolderController {
 @GetMapping("/hello")
 public String hello(){return "Hello Policyholder";}
}